from .index import wikilinks_plugin  # noqa: F401
