# sphinx-obsidian
Add capabilities to manage Obsidian MD in Sphinx
